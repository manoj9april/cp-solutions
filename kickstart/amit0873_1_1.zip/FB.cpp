#include<bits/stdc++.h>
using namespace std;

#define fore(i, l, r) for(int i = int(l); i < int(r); i++)
#define forn(i, n) fore(i, 0, n)

#define mp make_pair
#define pb push_back

#define x first
#define y second
#define ma 100001
typedef long long int ll;

int main()
{
	ios_base::sync_with_stdio(false);
    cin.tie(NULL);
	freopen("sample.in","r",stdin);
	freopen("sample1.out","w",stdout);
	int t; cin>>t; for(int z=1;z<=t;z++)
	{
		int n,m; cin>>n>>m;
		vector<pair<int,int> > Adj[n+1];
		int a,b=-1;
		while(m--)
		{
			int p,q,l; cin>>p>>q>>l;
			if(l==0)
			{
				a=p; b=q;
			}
			Adj[p].pb(mp(l,q));
			Adj[q].pb(mp(l,p));
			
		}
		
		for(int i=1;i<=n;i++)
		sort(Adj[i].begin(),Adj[i].end());
		vector<int> G[n+1];
		for(int i=1;i<=n;i++)
		{
			int p=Adj[i][0].y;
			bool f=false;
			for(int k=0;k<G[p].size();k++)
			{
				if(G[p][k]==i)
				f=true;
			}
			if(!f)
			G[p].pb(i);
			f=false;
			for(int k=0;k<G[i].size();k++)
			{
				if(G[i][k]==p)
				f=true;
			}
			if(!f)
			G[i].pb(p);
		}
		ll ans=1;
		bool v[n+1]={0};
		memset(v,0,sizeof(v));
		
		for(int i=1;i<=n;i++)
		{
			if(!v[i])
			{       
				bool f=false;
				queue<int> Q;
				Q.push(i);
				v[i]=true;
				while(!Q.empty())
				{
					int p=Q.front();  Q.pop();
					if(b!=-1 && p==b)
					f=1;
					for(int i=0;i<G[p].size();i++)
					{
						int q=G[p][i];
						if(!v[q])
						{
							Q.push(q); v[q]=true;
						}
					}
				}
				if(f)
				{
					ll z=G[a].size()+G[b].size()-2;
					
					ans*=2*pow(2,z);
				}
				else
				ans*=2;
			}
		}
		cout<<"Case #"<<z<<": "<<ans<<"\n";
	}
	return 0;
}
